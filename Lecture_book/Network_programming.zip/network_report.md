# 나는 공부한다 네트워크를

## 1.echo_TCP_Server

```c
int listenfd, connfd;
socklen_t clilen;
pit_t childpid;
struct sockaddr_in servaddr, cliaddr;

listenfd = Socket(AF_INET, SOCK_STREAM, 0);
bzero(&servaddr, sizeof(servaddr));
servaddr.sin_familly = AF_INET;
servaddr.sin_port = htons(atoi(argv[2]));
servaddr.sin_addr.s_addr = htonl(INADDR_ANY);

Bind(listenfd, (SA*)&servaddr, sizeof(servaddr));
Listen(listenfd, LISTENQ);

for( ; ; ){
    clilen = sizeof(cliaddr);
    connfd = Accept(listenfd, (SA*)&servaddr, clilen);
    if((childpid = fork())==0){
        Close(listenfd);
        str_echo(connfd);
        exit(0);
    }
    Close(connfd);
}
```



## 2. slow systemcall

**Function**

* wait()
* waitpid()

| 두 함수의 공통점     | 자식 프로세스가 종료될 때까지 대기합니다.                    |
| -------------------- | ------------------------------------------------------------ |
| **두 함수의 차이점** | **wait()는 자식 프로세스가 종료될 때까지 block되지만 <br />waitpid()는 WNOHANG 옵션을 사용하면 block되지 않고 <br />다른 작업을 진행할 수 있습니다.** |

| **형태**     | pid_t waitpid(pid_t pid, **int** *status, **int** options); |
| ------------ | ----------------------------------------------------------- |
| **인수**     | pid_t pid감시할 자식 프로세스ID                             |
| #            | **int status**자식 프로세스의 종료 상태 정보                |
| #            | **int status**자식 프로세스의 종료 상태 정보                |
| #            | **int options**대기를 위한 옵션                             |
| **반환 int** | 정상: 종료된 자식 프로세스 ID                               |
| #            | 실패: -1                                                    |
| #            | WNOHANG를 사용했고 자식 프로세스가 종료되지 않았다면: 0     |



### str_cli

```c
void str_cli(FILE *fp, int sockfd){
    int maxfdp1;
    fd_set rset;
    char sendline[MAXLINE], recvline[MAXLINE];
    
    FD_ZERO(&rset);
    
    for( ; ; ){
        FD_SET(sockfd, &rset);
        FD_SET(fileno(fp), &rset);
        maxfdp1 = max(fileno(fp), sockfd)+1;
        
        if(FD_ISSET(sockfd, &rset)){
            if(readline(sockfd, recvline, MAXLINE)<0)
                err_quit("에러 발생");
            fputs(recvline, stdout);
        }
        if(FD_ISSET(fileno(fp), &rset)){
            if(fgets(sendline, MAXLINE, fp)==NULL)
                return;
            Writen(sockfd, sendline, strlen(sendline));
        }
    }
}
```



## 3. 블록 모드

￭ 소켓에 대해 시스템 콜 호출시 시스템이 동작 완료할 때까지 시스템 콜에서 프로세스가 멈추
어 있는 모드
￭ 소켓을 처음 생성할 때 디폴트로 블록 모드가 됨
￭ 블록 모드의 소켓을 사용하는 프로그램에서 프로세스가 영원히 블록 상태가 될 수 있음
￭ 소켓 관련 시스템 콜 중에 블록될 수 있는 예
‒ listen(), connect(), accept(), recv(), send(), read(), write(), recvfrom(), sendto(), close()
￭ 응용 프로그램이 일 대 일 통신을 하거나 한가지 작업만 할 경우에 사용