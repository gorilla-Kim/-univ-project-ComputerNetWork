



[TOC]



# 네트워크 프로그래밍

**4/25 19:00 (Middle-test)**

## 2019-03-12

* .(파일명) : 숨김파일
* pwd : 현제경로 
* cd : change directory
  * cd ~ : user path 로 이동
* ls : list
  * ls -a : 모든 파일 보이기 (숨김파일도)
  * ls -l : 상세하게 나타내기
  * ls (찾고자 하는 파일) : 특정 파일 존재여부 확인
  * ls -al : 모든파일 상세보기
* mkdir : make directory
* rmdit: remove directory
* mv : move file
* rm : remove file
* more : 파일 내용을 한 화면씩 bash에 출력
* cp : copy (특정 파일이나 디렉토리를 다른 이름으로 복사)
  * cp [option] (원본파일명) (새로운파일명)
  * cp -r dir1 dir2 : dir1 을 dir2로 현재 경로에 모두 복사



## 2019-03-19

* **rm** 

  * remove
  * 완전삭제시 사용(사용시 주의요망!)
  * -r (recursive) : 상위디렉토리 모두 지우기

* **mv**

  * move

  * 파일 이름을 바꾸거나 이동

  * mv (file1) (file2) : 이름 변경

    ```bash
    mv (file1) (file2)
    ```

  * mv (file1) (dir1 ): 파일1을 dir1경로로 이동

* **touch**

  * 파일 생성 및 수정시간 변경

  * 지정한 파일이 존재하지 않으면 생성

    ```bash
    touch [option] file
    ```

* **vi editor** 

  * ```bash
    vi (filename)
    ```

  * 입력모드

    * i, I, a, A, o, O
      * i는 마우스커서 앞에서부터 수정시작
      * a는 마우스커서 뒤에서부터 수정시작
      * o 는 다음줄부터 수정시작
      * O는 첫째줄부터 수정시작
    * 처음 시작시 명령모드로 시작.
    * yy : 복사(한줄)
    * 3yy: 3줄 복사
    * dd : 현재행을 오려내기
    * p : 복사내용 붙여넣기
    * P : 현재행의 위에줄에 붙여넣기

  * 명령모드

    *  esc
    *  x : 명령모드에서 값을 지우고 싶을때
    *  dd : 한줄만 지우고 싶을때
    *  2dd : 줄 두개를 지우고 싶을때
    *  3dd: 줄 3개를 지우고 싶을때
    *  u : 방금 수행한 명령 취소
    *  방향
       *  h : 왼쪽
       *  j : 아래
       *  k : 위
       *  l : 오른쪽

  * 마지막행 모드

    * " : "
      * w : 저장
        * w 파일명 : 이름을 변경하고 저장
      * wq : 저장 후 종료
      * ZZ : 위와동일
      * q! : 강제 종료
    * /문자행 : 현재 위치부터 파일 뒤쪽으로 찾고자 하는 문자행을 찾아줌
      * n : 같은 문자행 다음번째꺼 찾기
      * N : 역방향으로 찾기
    * ?문자행 : 현재 위치부터 파일 위쪽으로 찾고자 하는 문자행을 찾아줌 
    * Ctrl + b : 한 화면 위로
    * Ctrl + f : 한 화면 아래로
    * 50 Enter : 50번째 줄로 이동

  * Shell

    * 로그인 쉘 : 사용자가 로그인한 직후 자동 생성되는 쉘

    * 서브 쉘 : 사용자가 직접 실행한 쉘

    * meta문자

      * ; 
        : 한줄에 여러개의 명령 입력

      *  '*' 
        : 임의의 문자를 나타내는 문자들

        * ls *.txt

      * | (파이프)
        : |(파이프) 양쪽에 명령이 와야 합니다.

        * 한 명령의 실행결과를 다음 명령의 입력으로 전달

          ```bash
          $ ls -l /etc | more
          ```

      * <, >, >>
        : 입출력 방향전환

        * ```bash
          $ 명령  >  파일명
          $ 명령 >> 파일명
          ```

          표준출력을 모니터에서 파일로 변경

        * '>' : 새로운 파일로 생성, 기존 파일의 내용은 없어짐

        * '>>' : 기존 파일의 끝에 내용 추가

        * '<' : 특정 파일에 입력된 내용을 파일로 넣기

    * 표준입력

      * 프로그램 실행에 필요한 데이터를 읽어드리는 기본 장치

    * 표준출력

      * 프로그램의 실행 결과를 출력하는 장치

    * 표준오류

      * 프로그램 실행중 발생한 오류 메시지를 출력하는 장치

  * 파일사용 권한

  * r :read

  * w :write

  * x :excution

  * 소유자  |  그룹사용자  |  시타사용자

  * chmod : change mode

    * 자신이 소유한 파일의 사용권한을 변경
    * 옵션 :  
      -r : 하위 디렉토리 포함
    * 모드 :
      변경할 사용권한 표시 : 기호모드, 숫자모드

  * grep
    : 파일내용검색

    * -i : 대소문자 구분 무시후 검색
    * -l : 해당 패턴이 들어있는 파일 이름을 출력
    * -n : 각 라인의 번호도 출력
    * -v : 명시된 패턴과 일치하지 않는 이름을 출력
    * -c : 패턴과 일치하는 라인 수 출력
    * -w : 패턴이 하나의 단어로 된것만 출력

  * fgrep
    : 문자열 검색

    * grep 으로 통합이 되었다.



## 2019-04-09

Simple Daytime Client

* 우리가 한학기동안 배우는 전체 내용을 내포

* err_sys
  : 시스템 에러 결과값을 출력해줍니다.
* inet_pton
  : 첫번째 매개값을 원하는 비트로 변경해 저장합니다.
  * IP주소를 저장할 때 사용합니다.

* 중요한 값이 0보다 작은면 모두 error!
* connect
  : 연결을 요청하는 함수
* read
  : 원하는 서버로부터 메세지를 받아옵니다.
* recvline
  : 화면에 반환할 값을 저장할 변수 
  * 사이즈가 +1로 구현 : 마지막 널문자를 넣기 위함.
* fputs(recvline, stdout)
  * 화면으로 결과물을 출력합니다.
  * 이유? 그냥 더 로우 레벨로 구현
* EOF = 0 (End Of File)
* exit()
  : 종료 함수

* wrapper function [Socket]
  : 에러를 출력하는 함수
  * 책 저자가 만든함수
  * socket != Socket
* errno 전역변수
  : Kernel이 사용하는 에러 언어
  * 왜 에러가 발생했는지를 알기위함.
  * 보통 각 해당하는 에러넘버를 전역변수로 만들어 두어서 사용자가 사용하기 쉽게 정의해 둔다.
    * sys/errno.h 안에 선언이 되어있습니다.
    * < > : C compiler가 사용하고 있는 라이브러리 디렉토리
* Accept
  : 
  * 사용하는 순간 Kernel로 권한이 넘어갑니다 ( trap )
* time
  : 특정 날짜부터 오늘까지 얼마의 시간이 지났는지를 저장하는 함수
  * 초단위로 반환합니다.
* ctime
  : time 값을 기반으로 문자열로 시간 및 날짜를 나타냅니다.
* sprintf
  : 출력의 방향이 변수(메모리)입니다.
* snprintf
  : 문자열  입력 옵션을 사용할 수 있는 모델입니다.
* sscanf
  : 변수에서 값을 읽어 옵니다.
* 단일 스레드로 이루어지는 서버를 interative서버라고 부릅니다.
* ISO
  : 국제 표준화 기구



--------



* netstat
  : 네트워크 상태를 나타내 줍니다.
  * 127.0.0.1 [localhost]
* mac address
  : 하드웨어 고유 식별번호
  * 한 홉을 건너갈 때 사용합니다.
  * 한 링크를 건너갈 때 사용합니다.
  * 6바이트로 이루어 집니다.
  * 브로드케스트(broadcast) 주소
    : 모든 라우터들에게 메시지를 보낼때 사용하는 주소
* ping
  : 네트워크가 살아있는지 유무를 확인할 때 사용합니다.
  * OS의 ICNP 프로토콜이 ping 메시지를 받아 응답을 해줍니다.



int argc

* argument counter : 파라미터의 갯수를 저장한다.

char **argv

* argument value : 각 파라미터들을 배열의 형태로 저장한다.





-------------

32bit 기반은 2^32 = 4GB 이다.

Q. ) 64bit 환경에서 32bit 소프트웨어를 실행하면 돌아가는가?

A. )	네, 돌아갑니다. 하지만 일부 프로그램은 실행이 안될 수 있습니다.
​	그 이유는 2^64의 공간의 포인터가 매개값으로 넘어올 수 있는데, 소프트웨어가
​	인지하지 못해서 문제가 발생합니다.



* int64_t i = 2^40
  : 64비트짜리 integer
* uint64_t i = 2^40
  : 64비트짜리 양수형 integer





--------

## 2019-04-16

#### # TCP

* 괴장히 섬세하다
* <b style="background-color:yellow">reliable</b>
  * byte stream
  * OS level에서 손실된 데이터를 감지하여 재전송합니다.
    * ACK 컨트롤 메시지가 존재(TCP에만 있는 특징)
  * threshold(임계값) 까지만 재전송합니다.
    * EX) 8번까지만 전송을 시도해보고 무응답시 연결해제
      이후 실패했다는것을 상대방에게 알린다.
* 정확성을 우선순위
* Complex(복잡한) protocol
* <b style="background-color:yellow">in-order delivery</b>
  * OS가(TCP layer에서) 순서에 맞게끔 User level application으로 전송합니다.
* <b style="background-color:yellow">Flow control</b>
  * 라우터마다 Buffer가 존재하는데 해당 버퍼안의 남은공간 크기에따라 데이터를 전송한다.
* <b style="background-color:yellow">동시에 양방향 연결이 가능</b>한 프로토콜이다.
  * 상태번호가 저장되어 있어야 합니다.
    * 보낼 때 <b style="background-color:skyblue">sequence number</b>
    * 받을 때 sequence number

#### # SCTP (별로 중요하지 않음)

* <b style="background-color:yellow">TCP와 유사하지만 message의 boundary가 존재</b>합니다.
  * 메시지 크기의 범위가 존재합니다.
* 잘 사용하지 않습니다.
  * 이유?
    : 이미 TCP가 시장을 선점했기 때문에 잘 사용하지 않습니다.

#### # UDP

* <b style="background-color:yellow">unreliable</b>

  * 전송이 보장되지 않습니다.
  * 손실된 데이터에 대해서 신경쓰지 않습니다.

* 속도를 우선순위

* SImple 한 모델

* message boundary가 존재

* UPD header

  * source
  * destination
  * checksum
  * length

* Controll message가 존재하지 않음

  * TCP는 존재한다 3Hand shake참고

* <<b style="background-color:yellow">하나의 소켓으로 다양한 사람에게 데이터를 전송하고 전송받을 수 있다.</b>

  * TCP소켓은 만들어진 소켓 하나당 대응되는 상대방이 하나가 생긴다.

    그러므로 하나의 소켓으로 여러명에게 보낼수도 받을수도 없다.

--------

* trace route
  * Ipv6와 Ipv4 둘다 사용



#### # TCP Management

<b style="background-color:yellow">3Way handshake</b>

Process / kernel 이 나누어져 있고 서로 소통한다.

1. SYN **J**
2. SYN **K**, ACK **J+1**

3. ACK **K+1**

Maximum segment size = TCP segment의 최대 크기이다. 

#### # TCP Connection Management

1. (Client) FIN **M** (Server로의 연결을 종료)
2. ACK **M+1** 
   * 이 상황에서는 Client는 데이터를 받을 수 있습니다.
   * half - close
3. FIN **N** (Client로의 종료)
4. (Client) ACK **N+1** 

**Time wait state**

* 바로 종료하지 않고 2MSL시간만큼 기다렸다가 종료를 한다.

* 왜 사용?
  * 오래된 segment를 종료시키기 위해서
    * NEW 와 OLD간의 구분이 안된다.
  * Client 가 보낸 마지막 ACK이 손실될 수 있기때문에 (병목현상/ duplicate)

-----

#### # Port Number

**TCP**

CLIENT

* Process가 Kernel에 소켓 생성을 요청합니다.

* 이 소켓에는 로컬IP, 로컬PORT, 외부IP, 외부PORT가 저장됩니다.

* 이때 로컬PORT는 OS가 자동으로 생성해줍니다.

SERVER

* CLIENT와 마찬가지로 소켓에는 
* 로컬IP, 로컬PORT, 외부IP, 외부PORT가 저장됩니다.

- CLIENT로부터 SYN(+MSS) 요청이 왔을때 외부IP 외부PORT가 초기화가 됩니다.
  - PORT 번호는 소켓을 구분하기 위해 존재합니다.
  - Process당 port number를 한개이상 할당할 수 있습니다.

Well Known Ports (0 ~ 1023)

* 공공 Port

Registered Ports (1024 ~ 49151)

* 사설 Port

Dynamic or Private Ports (49152 ~ 65535)

* 아무나 사용가능한 port number
  * 주로 Client가 사용

(관리자권한이 있어야 well known port번호를 사용가능합니다.)

**UDP**

* 소켓에 로컬IP 와 로컬PORT만 있습니다.
  * 이 덕분에 Destication IP 와 PORT만 맞으면 어떤data든 받을 수 있습니다.

## 2019-05-07

### exec function 이란?

* 현재 존재하는 process를 disk에 있는 실행가능한 파일로 변경해주는 역할
* exec()에 매개값으로 들어오는 실행파일로 현재 파일을 지우고 
  새로들어온 실행 파일로 덮어씌워 실행시킵니다. 

* 이전에 있던 내용은 지워집니다.

Fork와 다릅니다

* fork는 새로운 Thread에서 파일을 새로이 실행시키지만,
  exec는 기존의 파일위에 덮에씌워 파일을 실행시킵니다.

-------

오늘 학습목표 : concurrent server를 더욱 자세히

일반적으로 server는 client로부터 request메시지가 올것이라 생각합니다.

<tcpserv01.c> 

* 여기에는 다식 thread에 대한 close(connfd); 가 없습니다.
* 과연 이게 가능한 일일까요?
* 가능합니다. OS가 해당 Process가 종료될때 관련된 Thread들을 모두 종료(close)시켜줍니다.