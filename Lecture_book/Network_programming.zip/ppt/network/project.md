[TOC]



## p3

daytime client와 daytime server를 port 번호도 입력 받을 수 있도록 수정하시오.

### daycliport.c

```c
#include	"unp.h"
#include	<stdlib.h>
int
main(int argc, char **argv)
{
	int					sockfd, n;
	char				recvline[MAXLINE + 1];
	struct sockaddr_in	servaddr;
/* ↓ 입력을 3개 받겠다는 의미(실행파일, 주소, 포트번호) */
	if (argc != 3)	
		err_quit("usage: a.out <IPaddress>");
/* 3번째로 입력한값(포트번호)가 1024이하(wellknow port)면 error 발생 */
	if (atoi(argv[2]) <= 1024)
		err_sys("well known port number error");
/* client측 소켓 descriptor를 생성합니다. */
	if ( (sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0)
		err_sys("socket error");
/* servaddr를 0으로 초기화 합니다. */
	bzero(&servaddr, sizeof(servaddr));
/* 인터넷 구조체 변수의 형식과 포트를 초기화합니다. */
	servaddr.sin_family = AF_INET;
	servaddr.sin_port   = htons(atoi(argv[2]));	/* daytime server */
    
/*  inet_pton : strptr에 의해 가르켜지는 문자열을 (숫자로)변환하기 위해 노력한다. 
그리고 결과를 포인 터 addrptr을 통해 이진수로 저장한다. 
만약 성공할 경우 1이 리턴된다. 
만약 입력 문자열이 조건 으로 지정된 family에 대한 유효하지 않은 표현이라면, 0이 리턴된다.  */
	if (inet_pton(AF_INET, argv[1], &servaddr.sin_addr) <= 0)
		err_quit("inet_pton error for %s", argv[1]);

/*  connect 함수는 TCP의 three-way handshake를 초기화한다. 
이 함수는 연결이 성립하거나 에러가 발생하였을 경우 반환한다.  */
	if (connect(sockfd, (SA *) &servaddr, sizeof(servaddr)) < 0)
		err_sys("connect error");

/* n은 Server로부터 읽어들인 데이터의 수를 저장한다. */
	while ( (n = read(sockfd, recvline, MAXLINE)) > 0) {
		/* 배열 끝에 0(EOF)를 넣어줍니다. */
        recvline[n] = 0;	/* null terminate */
		if (fputs(recvline, stdout) == EOF)
			err_sys("fputs error");
	}
	if (n < 0)
		err_sys("read error");

	exit(0);
}

```

* Client는 connect()를 호출하기 전에 bind() 함수를 호출할 필요는 없다. 
  커널은 필요하다면 ephemeral port와 source IP 주소를 선택한다. 

* #### socket()

  * socket() 함수로 소켓을 생성하는 것을 능동적 소켓이라고 한는데, 이것이 클라이언트 소켓이다.
    (자발적으로 연결을 요청하는 것이므로 능동적 소켓이라고 함). 

### daysrvport.c

```c
#include	"unp.h"
#include	<time.h>
#include	<stdlib.h>

int
main(int argc, char **argv)
{
	int					listenfd, connfd;
	struct sockaddr_in	servaddr;
	char				buff[MAXLINE];
	time_t				ticks;
	if(atoi(argv[1])<=1024)
		err_sys("Well known port error");

	listenfd = Socket(AF_INET, SOCK_STREAM, 0);
	
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
    
    /* IP주소를  Host byte → Network byte 순서로 */
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    /* 포트번호를  Host byte → Network byte 순서로 */
	servaddr.sin_port        = htons(atoi(argv[1]));	/* daytime server */

	Bind(listenfd, (SA *) &servaddr, sizeof(servaddr));
    /* listen()을 호출하면 socket은 listening socket으로 바뀌게 된다.  */
	Listen(listenfd, LISTENQ);

	for ( ; ; ) {
		connfd = Accept(listenfd, (SA *) NULL, NULL);

        ticks = time(NULL);
        snprintf(buff, sizeof(buff), "%.24s\r\n", ctime(&ticks));
        Write(connfd, buff, strlen(buff));

		Close(connfd);
	}
}
```

* #### 문자열과 숫자를 서로 변환하기

  * ```c
    #include <stdlib.h>    // atoi 함수가 선언된 헤더 파일
    ```

  * ```c
    num1 = atoi("123");    // 문자열을 정수로 변환하여 num1에 할당
    ```

* #### htons

  * short 메모리 값을 호스트 바이트 순서에서 네트워크 바이트 순서로 변경합니다.
  * 포트번호를  Host byte → Network byte 순서로

* #### htonl

  * IP주소를  Host byte → Network byte 순서로

* #### Bind

  * bind()를 호출하여 socket address 구조체를 채우고 
    server의 well-known port(사용자가 입력한 argv[1]값)에 연결한다. 

* #### Listen

  * listen()을 호출하면 socket은 listening socket으로 바뀌게 된다.
  * <b style="background-color: yellow">listen()함수는 close상태에 있는 서버 소켓(listenfd)을 수동적 소켓으로 바꾼다.</b>
  * <b style="background-color: yellow">listen()함수는 backlog queue라는 대기가능한 최대 연결 댓수를 지정한다.</b>
    * sockfd는 앞서 bind()함수를 통해 바인딩 된 소켓의 소켓 디스크립터이다.
      backlog값을 0으로 하면 default값이 설정된다.
    * **그렇다면 backlog는 무엇인가?**
      ![](C:\Users\Administrator\Desktop\class\3-1\네트워크프로그래밍\img\listen.PNG)

* #### Accept

  * <b style="background-color: yellow">이것은 아직 처리되지 않은 연결들이 대기하고 있는 큐에서 제일 처음 연결된 연결을 가져와서 새로운 연결된 소켓을 만든다.</b> 그리고 소켓을 가르키는 파일 지정자를 할당하고 이것을 리턴한다.
    * Accept가 성공하면, 결과 값은 커널이 자동으로 생성한 brand-new descriptor이다. 
      이 새로운 descriptor는 client와의 TCP 연결을 참조한다. 
    * Accept를 설명할 때, accept의 첫 인수를 listen socket이라 부르고, 
      accept가 반환하는 값을 연결 socket이라 부른다. 

------

### edaysrvport.c 

Practice 3.1의 daytime server를 수정하여 프로그램 실행 시 
연결을 요청한 <b style="background-color: yellow">[ client의 IP와 port 값도 출력 ]</b>하도록 개선하시오.

```c
#include	"unp.h"
#include	<time.h>
#include	<stdlib.h>

int
main(int argc, char **argv)
{
	int					listenfd, connfd;
	socklen_t len;
	struct sockaddr_in	servaddr, cliaddr;
	char				buff[MAXLINE];
	time_t				ticks;
	if(argc!=2)
		err_quit("argument error!");
	if(atoi(argv[1])<=1024)
		err_sys("Well known port error");

	listenfd = Socket(AF_INET, SOCK_STREAM, 0);
	
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port        = htons(atoi(argv[1]));	/* daytime server */

	Bind(listenfd, (SA *) &servaddr, sizeof(servaddr));

	Listen(listenfd, LISTENQ);

	for ( ; ; ) {
		len = sizeof(cliaddr);
		connfd = Accept(listenfd, (SA *) &cliaddr, &len);
		
        // 연결시 요청된 IP, port 찍기 
        printf("connection from %s, port %d\n",Inet_ntop(AF_INET, &cliaddr.sin_addr, buff, sizeof(buff)), ntohs(cliaddr.sin_port));
        
        ticks = time(NULL);
        snprintf(buff, sizeof(buff), "%.24s\r\n", ctime(&ticks));
        Write(connfd, buff, strlen(buff));
	//printf("%d",servaddr.sin_port)

		Close(connfd);
        
        // 종료시 server에 요청된 IP, port 찍기
        printf("disconnection from %s, port %d\n",Inet_ntop(AF_INET, &cliaddr.sin_addr, buff, sizeof(buff)), ntohs(cliaddr.sin_port));
	}
}
```

---------------------

### cdaysrvport.c

Practice 3.2의 daytime server를 수정하여 동시에 여러 client에게 서비스를 제공해 줄 수 있는 
<b style="background-color: yellow">[ concurrent server ]</b>를 구현하시오.

```c
#include	"unp.h"
#include	<time.h>
#include	<stdlib.h>

int
main(int argc, char **argv)
{
	int					listenfd, connfd;
	socklen_t len;
	struct sockaddr_in	servaddr, cliaddr;
	char				buff[MAXLINE];
	time_t				ticks;
	pid_t pid;

	if(argc!=2)
		err_quit("argument error!");

	if(atoi(argv[1])<=1024)
		err_sys("Well known port error");

	listenfd = Socket(AF_INET, SOCK_STREAM, 0);
	
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family      = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port        = htons(atoi(argv[1]));	/* daytime server */

	Bind(listenfd, (SA *) &servaddr, sizeof(servaddr));

	Listen(listenfd, LISTENQ);

	for ( ; ; ) {
		len = sizeof(cliaddr);
		connfd = Accept(listenfd, (SA *) &cliaddr, &len);
		printf("connection from %s, port %d\n",Inet_ntop(AF_INET, &cliaddr.sin_addr, buff, sizeof(buff)), ntohs(cliaddr.sin_port));

		if((pid = Fork()) == 0){
            /* 단하나의 일만 수행하기에 listen소켓은 닫습니다. */
			Close(listenfd);	
            
		    ticks = time(NULL);
		    snprintf(buff, sizeof(buff), "%.24s\r\n", ctime(&ticks));
		    Write(connfd, buff, strlen(buff));
            
			/* 다음 문장으로 exit()함수가 오기에 선택사항입니다.*/
            Close(connfd);
			/* 일이 끝난 후엔 반드시 종료해주어야 합니다. */
            exit(0);
		}
        /* 반드시 닫아주어야 합니다. */
		Close(connfd);
	}
}
```

* #### pid_t pid

  * fork() 함수결과 프로세스(child)의 프로세스 ID를 저장하기 위한 변수입니다.

* #### Folk()

  * Fork를 부르는 것이 새 프로세스를 만드는 유일한 길 이므로 프로세스는 먼저 fork를 호출하여 자신의 복사본을 만든 후에 둘 중의 하나가(보통 자식 프로세스) exec(다음에 설명한다)를 호출하여 자식을 새 프로그램으로 대체한다. 

* #### reference count

  * Reference count는 file table entry에 있으며, 
    파일이나 소켓을 참조하는 open descriptor의 현재 개수를 센다.

## p4

simple TCP echo server program을 작성하시오.

### p41sechosrv.c

```c
#include "unp.h"

int 
main(int argc, char **argv)
{
	int listenfd, connfd;
	pid_t childpid;
	socklen_t clilen;
	struct sockaddr_in cliaddr, servaddr;
	
	listenfd = Socket(AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(SERV_PORT);

	Bind(listenfd, (SA*)&servaddr, sizeof(servaddr));

	Listen(listenfd, LISTENQ);
	
	for(;;) {

		clilen = sizeof(cliaddr);
		connfd = Accept(listenfd, (SA*) &cliaddr, &clilen);

		if((childpid = Fork())==0){

			Close(listenfd);
			str_echo(connfd);
			exit(0);
		}
		Close(connfd);
	}
}
```

TCP echo client program을 작성하시오.

* #### str_echo()

  * 함수 str_echo는 각 클라이언트를 위해 서버가 해야 할 일을 수행한다. 즉, 클라이언트로부터 행 을 읽어 다시 클라이언트에 되돌려 준다. 

    ```c
    #include    "unp.h" 
    void  
    str_echo(int sockfd)  
    {  
        ssize_t n;  
        char    buf[MAXLINE]; 
      
        again:  
        while ( (n = read(sockfd, buf, MAXLINE) ) > 0)  
            Writen(sockfd, buf, n); 
     
        if (n < 0 && errno == EINTR) 
            goto again; 
        else if (n < 0) 
            err_sys("str_echo: read error"); 
    } 
    ```



### p42echocli.c

```c
#include "unp.h"

int
main(int argc, char** argv)
{
	
	int sockfd;
	struct sockaddr_in servaddr;

	if(argc != 2)
		err_quit("usage: tcpcli <IPaddress>");
	
	sockfd = Socket(AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr,sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(SERV_PORT);
	Inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

	Connect(sockfd, (SA*)&servaddr, sizeof(servaddr));

	str_cli(stdin, sockfd);

	exit(0);
}
```

* #### str_cli

  * str_cli() 함수는 클라이언트의 일을 반복해서 수행한다. 즉, 표준 입력에서 문자열 을 받아 서버로 보내고, 서버로부터의 메아리를 읽고, 표준 출력에 보여준다. 

    ```c
    #include    "unp.h" 
      
    void  
    str_cli(FILE *fp, int sockfd)  
    {  
        char    sendline[MAXLINE], recvline[MAXLINE]; 
      
        while (Fgets(sendline, MAXLINE, fp) != NULL) { 
      
            Writen(sockfd, sendline, strlen (sendline)); 
      
            if (Readline(sockfd, recvline, MAXLINE) == 0)  
                err_quit("str_cli: server terminated prematurely"); 
     
            Fputs(recvline, stdout); 
    	} 
    } 
    ```

------------

### p43shechosrv.c

<b style="background-color: yellow">[ 좀비프로세스가 없는 ]</b>**concurrent echo server**에서 SIGCHILD signal을 처리하는 echo server를 작성하시오.

```c
#include "unp.h"

void
sig_chld(int signo)
{
	pid_t	pid;
	int	stat;
	
	while( (pid = waitpid(-1, &stat, WNOHANG) ) > 0)
		printf("child %d terminated\n", pid);
	return;
}

int
main(int argc, char** argv)
{
	int listenfd, connfd;
	pid_t childpid;
	socklen_t clilen;
	struct sockaddr_in cliaddr, servaddr;
	void sig_chld(int);
	
	listenfd = Socket(AF_INET, SOCK_STREAM, 0 );

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(SERV_PORT);
	
	Bind(listenfd, (SA*)&servaddr, sizeof(servaddr));

	Listen(listenfd, LISTENQ);

	Signal(SIGCHLD, sig_chld);

	for(;;){
		clilen = sizeof(cliaddr);

		if( (connfd = accept(listenfd, (SA*)&cliaddr, &clilen) ) < 0){
			
			if(errno == EINTR)
				continue;
			else
				err_sys("accept error");
		}
		
		if( (childpid = Fork()) == 0){

			Close(listenfd);
			str_echo(connfd);
			exit(0);

		}
		Close(connfd);
	}
}
```

---------

client에서 두 정수를 server에게 binary 형태로넘겨 주면 이를 더한 결과를 binary 형태로 
client에게 전송해 주는 프로그램을 작성하시오.

### p44calcli.c

```c
#include	"unp.h"
#include <stdint.h>
struct args {
	int32_t	arg1; // int32_t 가 아닌 int를 쓰면 endian 불일치 문제가 발생합니다.
	int32_t	arg2; // 이하동일
};

struct result {
	int32_t	sum; // 이하동일
};

void
str_cli (FILE *fp, int sockfd)
{
	char 	sendline[MAXLINE];
	struct	args args;
	struct	result result;

	while(Fgets(sendline, MAXLINE, fp) != NULL){
		
		if(sscanf(sendline, "%d%d",  &args.arg1 , &args.arg2) != 2){
			printf("invalid input: %s", sendline);
			continue;
		}
		Writen(sockfd, &args, sizeof(args));

		if(Readn(sockfd, &result, sizeof(result)) == 0)
			err_quit("str_cli: server terminated perematurely");
		printf("%d\n", result.sum);
	}
}

int
main(int argc, char **argv)
{
	int	sockfd;
	struct	sockaddr_in servaddr;
	
	if(argc != 2)
		err_quit("usage: tcpcli <IPaddress>");

	sockfd = Socket(AF_INET,SOCK_STREAM,0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(SERV_PORT);
	Inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

	Connect(sockfd, (SA *)&servaddr, sizeof(servaddr));

	str_cli(stdin, sockfd);

	exit(0);
}
```



### p44calser.c

```c
#include	"unp.h"

struct args {
	int32_t	arg1; // int32_t 가 아닌 int를 쓰면 endian 불일치 문제가 발생합니다.
	int32_t	arg2; // 이하동일
};

struct result {
	int32_t	sum;  // 이하동일
};
void
sig_chld(int signo)
{

	pid_t	pid;
	int	stat;
	
	while( (pid = waitpid(-1, &stat, WNOHANG) ) > 0)
		printf("child %d terminated\n", pid);
	return;
}

void
str_echo (int sockfd)
{

	ssize_t	n;
	struct	args args;
	struct	result result;

	for(;;){
		if((n = Readn(sockfd, &args, sizeof(args)))==0)
			return;
		
		result.sum = args.arg1 + args.arg2;
		Writen(sockfd, &result, sizeof(result));
	}
}

int
main(int argc, char** argv)
{
	int listenfd, connfd;
	pid_t childpid;
	socklen_t clilen;
	struct sockaddr_in cliaddr, servaddr;
	void sig_chld(int);
	
	listenfd = Socket(AF_INET, SOCK_STREAM, 0 );

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(SERV_PORT);
	
	Bind(listenfd, (SA*)&servaddr, sizeof(servaddr));

	Listen(listenfd, LISTENQ);

	Signal(SIGCHLD, sig_chld);

	for(;;){
		clilen = sizeof(cliaddr);

		if( (connfd = accept(listenfd, (SA*)&cliaddr, &clilen) ) < 0){
			
			if(errno == EINTR)
				continue;
			else
				err_sys("accept error");
		}
		
		if( (childpid = Fork()) == 0){

			Close(listenfd);
			str_echo(connfd);
			exit(0);

		}
		Close(connfd);
	}
}
```

 시그널처리 과정에서 다음 사항을 명심해야한다. 

1. 자식 프로세스를 fork할 때 SIGCHLD 신호를 포착해야 한다.
2. 신호를 포착할 때 interrupted system 호출을 처리해야 한다.
3. SIGCHLD handler는 좀비가 남지 않도록 waitpid를 사용하여 올바르게 해결해야 한다. 

-----------

## p5

### p51echocli.c

<b style="background-color: yellow">select()를 이용</b>하여 server와 keyboard로부터 입력을 동시에 감시할 수 있는 
TCP echo client 프로그램을 작성하시오.

```c
#include "unp.h"

void
str_cli(FILE *fp, int sockfd)
{

	int maxfdp1;
	fd_set rset;
	char sendline[MAXLINE], recvline[MAXLINE];
	
	FD_ZERO(&rset);
	for( ; ; ){

		FD_SET(fileno(fp), &rset);
		FD_SET(sockfd, &rset);
		maxfdp1 = max(fileno(fp), sockfd)+1;
		select(maxfdp1, &rset, NULL,NULL,NULL);
		if(FD_ISSET(sockfd, &rset)){
			if(read(sockfd, recvline, MAXLINE)==0)
				err_quit("str_cli: server terminated permaturely");
			fputs(recvline, stdout);
		}
		if(FD_ISSET(fileno(fp), &rset)){
			if(fgets(sendline, MAXLINE, fp) == NULL)
				return;
			write(sockfd, sendline, strlen(sendline));
		}		
	
	}
}
int
main(int argc, char** argv)
{
	
	int sockfd;
	struct sockaddr_in servaddr;

	if(argc != 2)
		err_quit("usage: tcpcli <IPaddress>");
	
	sockfd = Socket(AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr,sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(SERV_PORT);
	Inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

	Connect(sockfd, (SA*)&servaddr, sizeof(servaddr));

	str_cli(stdin, sockfd);

	exit(0);
}

```

* ```c 
  void FD_ZERO(fd_set *fdset);  /* clear all bits in fdset */
  ```

* ```c 
  void FD_SET(int fd, fd_set *fdset); /* turn on the bit for fd in fdset */
  ```

* ```c 
  void FD_CLR(int fd, fd_set *fdset); /* turn off the bit for fd in fdset */
  ```

* ```c 
  void FD_ISSET(int fd, fd_set *fdset);/* is the bit for fd on in fdset ? */
  ```



### p52echocli.c

select()를 이용하여 server와 keyboard로부터 입력을 동시에 감시할 수 있는 
TCP echo client 프로그램을 <b style="background-color: yellow">batch-mode</b>로 작성하시오.

```c
#include "unp.h"

void
str_cli(FILE *fp, int sockfd)
{

	int maxfdp1, stdineof;
	fd_set rset;
	char buf[MAXLINE];
	int n;
	stdineof = 0;
	FD_ZERO(&rset); 
	
	for( ; ; ){
		if(stdineof == 0)
			FD_SET(fileno(fp), &rset);
		FD_SET(sockfd, &rset);
		maxfdp1 = max(fileno(fp), sockfd)+1;
		select(maxfdp1, &rset, NULL,NULL,NULL);

		if(FD_ISSET(sockfd, &rset)){
			if((n = read(sockfd, buf, MAXLINE))==0){
				if (stdineof == 1)
					return;
				else
					err_quit("str_cli:server terminated");
			}
			write(fileno(stdout), buf, n);
		}
		if(FD_ISSET(fileno(fp), &rset)){
			if((n = read(fileno(fp), buf, MAXLINE))==0){
				stdineof = 1;
				shutdown(sockfd, SHUT_WR);
				FD_CLR(fileno(fp), &rset);
				continue;
			}
			write(sockfd, buf, n);
		}		
	
	}
}
int
main(int argc, char** argv)
{
	
	int sockfd;
	struct sockaddr_in servaddr;

	if(argc != 2)
		err_quit("usage: tcpcli <IPaddress>");
	
	sockfd = Socket(AF_INET, SOCK_STREAM, 0);

	bzero(&servaddr,sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(SERV_PORT);
	Inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

	Connect(sockfd, (SA*)&servaddr, sizeof(servaddr));

	str_cli(stdin, sockfd);

	exit(0);
}

```

### p53echosrv.c

select()를 이용하여 하나의 process로 여러 client를 처리할 수 있는 
echo server를 작성하시오.

```c
#include "unp.h"

int
main(int argc, char** argv)
{
	int i, maxi, listenfd, connfd, sockfd, maxfd;
	int nready, client[FD_SETSIZE];
	ssize_t	n;
	fd_set rset, allset;
	char buf[MAXLINE];
	socklen_t clilen;
	struct sockaddr_in cliaddr, servaddr;
	
	listenfd = Socket(AF_INET, SOCK_STREAM, 0 );

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(SERV_PORT);
	
	Bind(listenfd, (SA*)&servaddr, sizeof(servaddr));

	Listen(listenfd, LISTENQ);
	maxfd = listenfd;
	maxi= -1;

	for(i = 0; i<FD_SETSIZE; i++)
		client[i] = -1;
	FD_ZERO(&allset);
	FD_SET(listenfd, &allset);

	for(;;){
		rset = allset;
		nready = Select(maxfd+1, &rset, NULL, NULL, NULL);
		if(FD_ISSET(listenfd, &rset)){
			clilen = sizeof(cliaddr);
			connfd = Accept(listenfd, (SA *)&cliaddr, &clilen);
			for( i = 0; i< FD_SETSIZE; i++){
				if(client[i] <0 ){
					client[i] = connfd;
					break;
				}
			}
			if( i == FD_SETSIZE)
				err_quit("too many clients");
			FD_SET(connfd, &allset);
			if(connfd>maxfd)
				maxfd = connfd;
			if(i> maxi)
				maxi = i;
			if(--nready<=0)
				continue;
		}
		
		for( i = 0; i<=maxi; i++){

			if( (sockfd = client[i]<0))
				continue;
			if(FD_ISSET(sockfd,&rset)){
				if((n=Read(sockfd,buf,MAXLINE))==0){
					Close(sockfd);
					FD_CLR(sockfd,  &allset);
					client[i]=-1;
				} else
					Writen(sockfd, buf, n);
				if(--nready<=0)
					break;
			}
		}
	}
}
```

## [ UDP ]

### p54udpechocli.c

<b style="background-color: yellow">sendto()와 recvfrom()을 이용</b>하여 UDP echo client와 server 프로그램을 작성하시오.

```c
#include "unp.h"

void
dg_cli(FILE *fp, int sockfd, const SA *pservaddr, socklen_t servlen)
{
	int n;
	char sendline[MAXLINE], recvline[MAXLINE+1];

	while(Fgets(sendline, MAXLINE, fp)!=NULL){
		Sendto(sockfd, sendline, strlen(sendline), 0, pservaddr, servlen);
		n = Recvfrom(sockfd, recvline, MAXLINE, 0, NULL, NULL);
		recvline[n] = 0;
		Fputs(recvline, stdout);
	}
}

int 
main(int argc, char **argv)
{
	int sockfd;
	struct sockaddr_in servaddr;

	if(argc != 2)
		err_quit("usage: udpcli <IPaddress>");
	
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(SERV_PORT);
	Inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

	sockfd = Socket(AF_INET, SOCK_DGRAM, 0);

	dg_cli(stdin, sockfd, (SA *)&servaddr, sizeof(servaddr));

	exit(0);
}
```

### p54udpechosrv.c

```c
#include "unp.h"

/*void

dg_echo(int sockfd, SA *pcliaddr, socklen_t clilen)
{
	int n;
	socklen_t len;
	char mesg[MAXLINE];
	
	for(;;){
		len = clilen;
		n = Recvfrom(sockfd, mesg, MAXLINE, 0, pcliaddr, &len);

		Sendto(sockfd, mesg, n, 0, pcliaddr, len);
	}
}
*/
int 
main(int argc, char **argv)
{
	int sockfd;
	struct sockaddr_in servaddr, cliaddr;

	sockfd = Socket(AF_INET, SOCK_DGRAM, 0);
	
	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(SERV_PORT);

	Bind(sockfd, (SA *)&servaddr, sizeof(servaddr));
	dg_echo(sockfd, (SA *)&cliaddr, sizeof(cliaddr));
}
```

----------------

### p55tuechosrv.c

TCP와 UDP 모두 서비스해 줄 수 있는 echo server 프로그램을 작성하시오.

```c
#include "unp.h"

void
sig_chld(int signo)
{
	pid_t pid;
	int stat;
	
	pid=wait(&stat);
	printf("child %d terminated\n",pid);
	return;
}

int
main(int argc, char** argv)
{
	int listenfd, connfd, udpfd, nready, maxfdp1;
	char mesg[MAXLINE];
	pid_t childpid;
	fd_set rset;	
	ssize_t	n;
	socklen_t len;
	const int on = 1;
	struct sockaddr_in cliaddr, servaddr;
	void sig_chld(int);
	
	listenfd = Socket(AF_INET, SOCK_STREAM, 0 );

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(SERV_PORT);
	
	Setsockopt(listenfd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
	Bind(listenfd, (SA*)&servaddr, sizeof(servaddr));
	Listen(listenfd, LISTENQ);
	udpfd = Socket(AF_INET, SOCK_DGRAM, 0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(SERV_PORT);

	Bind(udpfd, (SA*)&servaddr, sizeof(servaddr));
	Signal(SIGCHLD, sig_chld);

	FD_ZERO(&rset);
	maxfdp1 = max(listenfd, udpfd) + 1;

	for(;;){
		FD_SET(listenfd, &rset);
		FD_SET(udpfd, &rset);
		if((nready=select(maxfdp1, &rset, NULL, NULL, NULL))<0){
			if(errno == EINTR)
				continue;
			else
				err_sys("select error");
		}
		if(FD_ISSET(listenfd, &rset)){
			len = sizeof(cliaddr);
			connfd = Accept(listenfd,(SA*)&cliaddr, &len);
			if((childpid = Fork()) ==0){
				Close(listenfd);
				str_echo(connfd);
				exit(0);
			}
			Close(connfd);
		}
		if(FD_ISSET(udpfd,&rset)){
			len= sizeof(cliaddr);
			n = Recvfrom(udpfd, mesg, MAXLINE, 0, (SA*)&cliaddr, &len);

			Sendto(udpfd, mesg, n, 0, (SA*) &cliaddr, len);
		}
	}
}
```

## p6

서버에서 임의의 숫자를 클라이언트에게 전달하여 출력되도록 만들어라. 

### p45calser.c

```c
#include	"unp.h"

struct args {
	int32_t	arg1; // int32_t 가 아닌 int를 쓰면 endian 불일치 문제가 발생합니다.
	int32_t	arg2; // 이하동일
};

struct result {
	int32_t	sum;  // 이하동일
};
void
sig_chld(int signo)
{

	pid_t	pid;
	int	stat;
	
	while( (pid = waitpid(-1, &stat, WNOHANG) ) > 0)
		printf("child %d terminated\n", pid);
	return;
}
void
str_cli (FILE *fp, int sockfd)
{
	char 	sendline[MAXLINE];
	struct	args args;
	struct	result result;

	while(Fgets(sendline, MAXLINE, fp) != NULL){
		
		if(sscanf(sendline, "%d%d",  &args.arg1 , &args.arg2) != 2){
			printf("invalid input: %s", sendline);
			continue;
		}
        
        /* fgets으로 문자열을 읽고, writen으로 읽은 것을 서버에게 보낸다. */
		Writen(sockfd, &args, sizeof(args));
        
        /* ↓ 이 문제에서는 서버는 출력이 안되도 됩니다.(생략가능) */
		printf("%d\n", result.sum);
	}
}

int
main(int argc, char** argv)
{
	int listenfd, connfd;
	pid_t childpid;
	socklen_t clilen;
	struct sockaddr_in cliaddr, servaddr;
	void sig_chld(int);
	
	listenfd = Socket(AF_INET, SOCK_STREAM, 0 );

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(SERV_PORT);
	
	Bind(listenfd, (SA*)&servaddr, sizeof(servaddr));

	Listen(listenfd, LISTENQ);

	Signal(SIGCHLD, sig_chld);

	for(;;){
		clilen = sizeof(cliaddr);

		if( (connfd = accept(listenfd, (SA*)&cliaddr, &clilen) ) < 0){
			
			if(errno == EINTR)
				continue;
			else
				err_sys("accept error");
		}
		
		if( (childpid = Fork()) == 0){

			Close(listenfd);
			str_cli(stdin, connfd);
			exit(0);

		}
		Close(connfd);
	}
}
```

### p45calcli.c

```c
#include	"unp.h"
#include <stdint.h>
struct args {
	int32_t	arg1; // int32_t 가 아닌 int를 쓰면 endian 불일치 문제가 발생합니다.
	int32_t	arg2; // 이하동일
};

struct result {
	int32_t	sum; // 이하동일
};


void
str_echo (int sockfd)
{

	ssize_t	n;
	struct	args args;
	struct	result result;

	for(;;){
		if((n = Readn(sockfd, &args, sizeof(args)))==0)
			err_quit("str_cli: server terminated perematurely");
        
		result.sum = args.arg1 + args.arg2;
		Writen(sockfd, &result, sizeof(result));
		printf("%d\n", result.sum);
	}
}

int
main(int argc, char **argv)
{
	int	sockfd;
	struct	sockaddr_in servaddr;
	
	if(argc != 2)
		err_quit("usage: tcpcli <IPaddress>");

	sockfd = Socket(AF_INET,SOCK_STREAM,0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(SERV_PORT);
	Inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

	Connect(sockfd, (SA *)&servaddr, sizeof(servaddr));

	str_echo(sockfd);

	exit(0);
}
```

#### --ver2--

#### p46calcli.c

```c
#include	"unp.h"
#include <stdint.h>
struct args {
	int32_t	arg1;
	int32_t	arg2;
};

struct result {
	int32_t	sum;
};

void
str_cli (FILE *fp, int sockfd)
{

	char 	sendline[MAXLINE];
	struct	args args;
	struct	result result1, result2;

	while(Fgets(sendline, MAXLINE, fp) != NULL){
		int n;
		n = sscanf(sendline, "%d",  &result2.sum);
        if(n>1 || n <0){
            printf("%d, 다시입력!!\n",n);
            continue;
        }
		Writen(sockfd, &result2, sizeof(result2));
		if(Readn(sockfd, &result1, sizeof(result1)) == 0)
			err_quit("str_cli: server terminated perematurely");
		printf("client recieve num : %d\n", result1.sum);
	}
}

int
main(int argc, char **argv)
{
	int	sockfd;
	struct	sockaddr_in servaddr;
	
	if(argc != 2)
		err_quit("usage: tcpcli <IPaddress>");

	sockfd = Socket(AF_INET,SOCK_STREAM,0);

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_port = htons(SERV_PORT);
	Inet_pton(AF_INET, argv[1], &servaddr.sin_addr);

	Connect(sockfd, (SA *)&servaddr, sizeof(servaddr));

	str_cli(stdin, sockfd);

	exit(0);
}

```



#### p46calser.c

```c
#include	"unp.h"
#include <stdlib.h>
#include <time.h>
/*
struct args {
	int32_t	arg1;
	int32_t	arg2;
};
*/
struct result {
	int32_t	sum;
};
void
sig_chld(int signo)
{

	pid_t	pid;
	int	stat;
	
	while( (pid = waitpid(-1, &stat, WNOHANG) ) > 0)
		printf("child %d terminated\n", pid);
	return;
}

void
str_echo(int sockfd)
{

	ssize_t	n;
	//struct	args args;
	struct	result result1, result2;
	for(;;){
		if((n = Readn(sockfd, &result1, sizeof(result1)))==0){
            printf("client terminated!!\n");
            return;
        }
        printf("server recieve number : %d\n",result1.sum);
		srand(time(NULL));
		result2.sum = rand()%999+1;
        printf("server sending number : %d\n",result2.sum);
		Writen(sockfd, &result2, sizeof(result2));
        
        if(result1.sum == 0)
			return;
	}
}

int
main(int argc, char** argv)
{
	int listenfd, connfd;
	pid_t childpid;
	socklen_t clilen;
	struct sockaddr_in cliaddr, servaddr;
	void sig_chld(int);
	
	listenfd = Socket(AF_INET, SOCK_STREAM, 0 );

	bzero(&servaddr, sizeof(servaddr));
	servaddr.sin_family = AF_INET;
	servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
	servaddr.sin_port = htons(SERV_PORT);
	
	Bind(listenfd, (SA*)&servaddr, sizeof(servaddr));

	Listen(listenfd, LISTENQ);

	Signal(SIGCHLD, sig_chld);

	for(;;){
		clilen = sizeof(cliaddr);

		if( (connfd = accept(listenfd, (SA*)&cliaddr, &clilen) ) < 0){
			
			if(errno == EINTR)
				continue;
			else
				err_sys("accept error");
		}
		
		if( (childpid = Fork()) == 0){
			Close(listenfd);
			str_echo(connfd);
			exit(0);

		}
		Close(connfd);
	}
}

```

- 난수만들어서 전송하기

  - ```c
    #include <stdio.h>
    #include <stdlib.h>
    #include <time.h>
    
    int main() {
      
      srand(time(NULL));
      
      int random = rand();
      
      printf("%d", random);
    
      return 0;
    }
    ```

  - ```c
    rand()%n   // 0~(n-1) 범위의 난수 생성
    ```

  - ```c
    rand()%n+1 // 1~n까지 범위의 난수 생성
    ```
